package dev.trabajo.publicaciones;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PublicacionesApplicationTests {

	@Test
	void contextLoads() {
	}

}
